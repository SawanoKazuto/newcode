document.getElementById("p1").addEventListener("click", function(e){
	if(e.target && e.target.nodeName == "LI"){
		document.getElementById("p1").style.color = "#ff0000";
	}
});
//finished
document.getElementById("p2").addEventListener("click", function(e){
	if(e.target && e.target.nodeName == "LI"){
		var obj = document.getElementById("Li").getElementsByTagName("LI");
		obj[0].innerHTML = formatDate(new Date(), 'yyyy-MM-dd');
		console.log(formatDate(new Date(), 'yyyy-MM-dd'));
	}
});
function formatDate(dateTime, str){
	var z = {
		y: dateTime.getFullYear(),
		M: dateTime.getMonth() + 1,
		d: dateTime.getDate()
	};
	return str.replace(/(y+|M+|d+)/g, function(v){
		return ((v.length > 1 ? "0" : "") + eval('z.' + v.slice(-1))).slice(-(v.length > 2 ? v.length : 2))
	});
}
//finished
document.getElementById("p3").addEventListener("click", function(e){
	if(e.target && e.target.nodeName == "LI"){
		$(this).siblings('li').removeClass('active');
        $(this).addClass('active');
	}
});
//finished
document.getElementById("p4").addEventListener("click", function(e){
	if(e.target && e.target.nodeName == "LI"){
		var test = document.getElementById("Li").getElementsByTagName("LI");
		test[7].remove();
	}
});
//finished
document.getElementById("p5").addEventListener("click", function(e){
	if(e.target && e.target.nodeName == "LI"){
		window.open('https://www.taobao.com/', '_blank');
	}
});
//finished
document.getElementById("p6").addEventListener("click", function(e){
	if(e.target && e.target.nodeName == "LI"){
		var test = document.createElement("li");
		test.innerHTML = "p9";
		document.getElementById("Li").appendChild(test);
	}
});
//finished
document.getElementById("p7").addEventListener("click", function(e){
	if(e.target && e.target.nodeName == "LI"){
		var x = document.body.clientWidth;
		var div = document.getElementById("mydiv");
		console.log(div.style.width);
		div.style.width = x + "px";
		console.log(div.style.width);
	}
});
//finished